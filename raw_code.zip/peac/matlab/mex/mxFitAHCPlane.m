% ret=mxFitAHCPlane(xyz): run plane fitting
% mxFitAHCPlane(param_keys, param_vals): reset parameters
% mxFitAHCPlane(): report current parameters
